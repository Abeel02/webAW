
function isesion(){
    window.location.assign("Web2.html");
}
function Registro(){
    window.location.assign("InicioSesion.html");
}   
function Pago(){
    window.location.assign("Web2.html");
    window.alert("Tu reserva ha sido realizada");
}